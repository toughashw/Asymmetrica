#!/bin/sh
#generates an hash for the password WJOAmk6DMcC2CSka
psw=$(/usr/sbin/slappasswd -h {SSHA} -s "WJOAmk6DMcC2CSka")
cp /ldif_files/psw_update.ldif /ldif_files/psw_update_fixed.ldif
# the correct password is placed in the file, which has an invalid placeholder otherwise
sed -i "s@shaPSW@$psw@" "/ldif_files/psw_update_fixed.ldif"
ldapmodify -H ldapi:// -Y EXTERNAL -f /ldif_files/psw_update_fixed.ldif
rm /ldif_files/psw_update_fixed.ldif
