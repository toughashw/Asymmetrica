#!/bin/sh
curl --digest --user dba:SzsBcw0clsSfv3rP -X DELETE --url "http://$1:8890/sparql-graph-crud-auth?graph-uri=http://www.disit.org/km4city/resource/Ontology"

while read p; do
  echo $p
  curl --digest --user dba:SzsBcw0clsSfv3rP -X POST --url "http://$1:8890/sparql-graph-crud-auth?graph-uri=http://www.disit.org/km4city/resource/Ontology" -T "$p"
done < ontologies.list

docker-compose exec virtuoso-kb isql-v localhost dba SzsBcw0clsSfv3rP -H $1 "EXEC=rdfs_rule_set ('urn:ontology', 'http://www.disit.org/km4city/resource/Ontology');"
