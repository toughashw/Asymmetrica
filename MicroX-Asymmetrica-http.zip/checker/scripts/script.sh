#!/bin/bash

echo hello people!

